document.addEventListener("DOMContentLoaded", () => {
  const listaProduto = document.getElementById("lista-produto");

  function carrega() {
    fetch("http://localhost:3000/products")
      .then((response) => response.json())
      .then((data) => {
        data.forEach((product) => {
          const productHTML = `
          <custom-element>
            <img
              slot="imagem-produto"
              class="card-img-top"
              src="${product.image}"
              alt="${product.title}"
            />
            <p
              slot="nome-produto" 
              class="card-text fw-bold"
            >
              ${product.title}
            </p>
            <form
              slot="preco-produto"
              class="d-block"
            >
              ${product.price}
              <a href="bu.html" class="btn btn-secondary mx-3"
                ><span
                  class="material-symbols-outlined d-flex align-items-center"
                  >add</span
                ></a
              >
            </form>
          </custom-element>
        `;
          listaProduto.insertAdjacentHTML("beforeend", productHTML);
        });
      })
      .catch((error) => console.error("Erro ao carregar produtos:", error));
  }

  carrega();
});
